#Appmenu
alias appmenu='/opt/cubic_appmenu/appmenu.sh'

#NCS
alias ncsdir="cd /opt/bea/ncs" #NCS
alias ncslogs="cd /opt/bea/user_projects/domains12/nbms_domain/logs" #NCS


